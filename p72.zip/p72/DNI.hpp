#include <cstdio>
#include <iomanip>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <vector>
using namespace std;

const int  MIN = 30000000;
const int  MAX = 80000000;
class DNI{
	private:
		int dni;

	public:
		DNI(void){}
		~DNI(void){}
		int get_dni(){
			return dni;
		}
    	void set_dni(int dn){
    		dni = dn;
    	}
		int* generar(int TAMANOBANCO,int* banco){
			banco = new int[TAMANOBANCO];
			for(int i=0;i<TAMANOBANCO;i++){
			      banco[i] = MIN + (rand() % ( MAX - MIN));
			    
			}
			return banco;
		}

		void reset(int TAMANOBANCO, int* ref){
			for(int i=0;i<TAMANOBANCO;i++){
			      ref[i] = 0;
			    
			}
		}
		
		friend bool operator==(const DNI& a, const DNI& b){
			if(a.dni == b.dni)
        		return true;
    		else
        		return false;
		}
	    friend bool operator<=(const DNI& a, const DNI& b){
	    	if(a.dni <= b.dni)
        		return true;
    		else
        		return false;
	    }
	    friend bool operator>=(const DNI& a, const DNI& b){
	    	if(a.dni >= b.dni)
    			 return true;
    		else
        		return false;
	    }
	    friend bool operator<(const DNI& a, const DNI& b){
	    	if(a.dni< b.dni)
        		return true;
			else
        		return false;
	    }
	    friend bool operator>(const DNI& a, const DNI& b){
	    	if(a.dni > b.dni)
        		return true;
    		else
        		return false;
	    }
};