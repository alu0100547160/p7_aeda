#include <cstdio>
#include <iostream>
#include <cmath>
#include <vector>
#include "AVL.hpp"
#include "DNI.hpp"
using namespace std;


int main(void){

	//Variables
	int opc;
 	int dem;
 	int valor;
 	int n_nodos;
 	int tam;
 	int n_pruebas;
 	int in;
 	int* ref;
 	int* banco;

 	//instancias
 	DNI numeros;
 	AVL<int> arbol;
	AVL<int> arbol2;

 	//Para  imprimir los números aleatorios
 	
 	//for(int i=0;i<4;i++) {
 	//	cout << ref[i] << endl;
 	//}
  do{
 	cout << "   1. Modo Demostracion" << endl;
	cout << "   2. Modo Estadistica" << endl;
	cout << "   3. Salir " << endl;
	cout << "Opción: ";
	cin >> opc;

	if(opc == 1){
	  do{
		cout << "   [0] Salir" << endl;
		cout << "   [1] Insertar clave" << endl;
		cout << "   [2] Eliminar clave" << endl;
		cout << "Opción: ";
		cin >> dem;
		switch(dem){
			case 0:
				dem = 0;
				break;

			case 1:
				cout << endl;
				cout<<" Insertar: ";
				cin >> in;
				/* Nota si se quiere probar con enteros pequeños quitar condiciones */
				if(( in < MIN) || (in > MAX))
					cout << " El DNI no puede ser inferior a " << MIN << "ni mayor a " << MAX << endl;
				else
					arbol2.Insertar(in);

				break;
				
			case 2:
				arbol2.mostrar();
				cout <<"\n\n";
				cout << " Introduzca valor a eliminar: ";
				cin >> valor;
				arbol2.eliminar(valor);
				break;
				
			default:
				cout << "\nValor no encontrado " << endl;
				break;

		}
		arbol2.mostrar();
	
	  }while(dem != 0);
	}

	if(opc == 2){
		cout << "\nIntroduzca el número de nodos a insertar: ";
		cin >> n_nodos;
		cout << "Introduzca el número de pruebas: ";
		cin >> n_pruebas;

		//Variables comparaciones
	
		int compi[n_pruebas],mini,medi,maxi; //variables insertar
		int compb[n_pruebas],minb,medb,maxb; //variables búsqueda
		mini = 99999999;
		maxi = 0;
		medb = 0;
		medi = 0;
		minb = 99999999;
		maxi = 0;
	
		//Comienzo de comparaciones
		ref = numeros.generar(n_nodos,banco);
		for(int i = 0; i < n_nodos; i++){                
			arbol.Insertar(ref[i]);
		}

		for(int i = 0; i < n_pruebas; i++){                
			arbol.Buscar(ref[i]);
			if(arbol.comp_b > maxb)
				maxb = arbol.comp_b ; 
			if(arbol.comp_b < minb)
				minb = arbol.comp_b ; 
			medb += arbol.comp_b ; 
			arbol.reset();
		}

		numeros.reset(n_nodos,ref);
		ref = numeros.generar(n_nodos,banco);
	
			for(int i = 0; i < n_pruebas; i++){
				arbol.Buscar(ref[i]);
				if(arbol.comp_b > maxi)
					maxi = arbol.comp_b ; 
				if(arbol.comp_b <  mini)
					mini = arbol.comp_b ; 
					medi += arbol.comp_b ; 
					arbol.reset();
			}	

	// Resultado de las comparaciones
		cout << "              N....P....Mínimo...Medio...Máximo\n" << endl;
		cout << "Búsqueda      " << n_nodos  << "    " <<  n_pruebas << "        " << minb << "      " <<   medb/n_pruebas  <<  "     " << maxb  << endl;
		cout << "\nInsercción    " << n_nodos  << "    " <<  n_pruebas << "        " << mini << "      " <<   medi/n_pruebas  <<  "     " << maxi  << endl;
			
	} // fin opc 2

  }while (opc != 3);

	return 0;
}